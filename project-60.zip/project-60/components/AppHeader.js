import * as React from 'react';
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native';

export default class AppHeader extends React.Component {
  render() {
    return (
      <View>
        <TouchableOpacity style={styles.header}>
          <Text style={styles.text}>SCHOOL ATTENDANCE</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  header: {
    backgroundColor: 'crimson'   ,
    justifyContent: 'center' ,
    alignItems:'center'
  },

  text: {
    fontWeight: 'bold',
    color: '000',
    fontFamily:'Bookman Old Style',
    fontSize: 25,
    padding: 10,
    marginLeft:70
  },
});
